import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  Plus, 
  Calendar, 
  Bell, 
  Settings, 
  HelpCircle, 
  Archive, 
  Folder, 
  FileText,
  LogOut,
  X,
  MoreVertical,
  User,
  ExternalLink,
  CheckCircle2,
  BarChart3,
  Search,
  Filter,
  Copy,
  Hash
} from 'lucide-react';
import { cn } from '../lib/utils';
import CreateClassModal from '../components/CreateClassModal';
import JoinClassModal from '../components/JoinClassModal';
import ConfirmModal from '../components/ConfirmModal';
import { Class } from '../types';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  getDocs, 
  doc, 
  getDoc,
  deleteDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';

type ViewType = 'classes' | 'calendar' | 'notifications' | 'offline' | 'archived' | 'history' | 'settings' | 'help';

export default function Home() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>('classes');
  const [classes, setClasses] = useState<Class[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    variant?: 'danger' | 'warning' | 'info';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    if (!user) return;

    setIsLoading(true);
    
    // Fetch classes where user is teacher
    const teacherQuery = query(collection(db, 'classes'), where('teacherId', '==', user.id));
    
    // Fetch enrollments where user is student
    const enrollmentQuery = query(collection(db, 'enrollments'), where('studentId', '==', user.id));

    const unsubTeacher = onSnapshot(teacherQuery, (snapshot) => {
      const teacherClasses = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Class));
      
      // Also need to fetch classes for enrollments
      getDocs(enrollmentQuery).then(async (enrollSnapshot) => {
        const classIds = enrollSnapshot.docs.map(d => d.data().classId);
        const enrolledClasses: Class[] = [];
        
        for (const cid of classIds) {
          const cDoc = await getDoc(doc(db, 'classes', cid));
          if (cDoc.exists()) {
            enrolledClasses.push({ id: cDoc.id, ...cDoc.data() } as Class);
          }
        }

        // Combine and remove duplicates
        const all = [...teacherClasses, ...enrolledClasses];
        const unique = Array.from(new Map(all.map(item => [item.id, item])).values());
        setClasses(unique);
        setIsLoading(false);
      });
    });

    return () => unsubTeacher();
  }, [user]);

  const handleCreateClass = async (name: string, section: string) => {
    if (!user) return;

    const colors = ['bg-blue-600', 'bg-emerald-600', 'bg-purple-600', 'bg-orange-600', 'bg-rose-600'];
    const classCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    
    const newClassData = {
      name,
      section,
      teacherId: user.id,
      teacherName: user.name,
      teacherEmail: user.email,
      bannerColor: colors[Math.floor(Math.random() * colors.length)],
      classCode,
      createdAt: new Date().toISOString()
    };

    try {
      await addDoc(collection(db, 'classes'), newClassData);
    } catch (error) {
      console.error("Error creating class:", error);
    }
  };

  const handleJoinClass = async (code: string) => {
    if (!user) return;

    const q = query(collection(db, 'classes'), where('classCode', '==', code.toUpperCase()));
    const snapshot = await getDocs(q);

    if (snapshot.empty) {
      throw new Error('Invalid code');
    }

    const classDoc = snapshot.docs[0];
    const classId = classDoc.id;

    // Check if already enrolled
    const eq = query(collection(db, 'enrollments'), 
      where('studentId', '==', user.id), 
      where('classId', '==', classId)
    );
    const eSnapshot = await getDocs(eq);

    if (!eSnapshot.empty || classDoc.data().teacherId === user.id) {
      throw new Error('Already in class');
    }

    await addDoc(collection(db, 'enrollments'), {
      studentId: user.id,
      classId: classId,
      enrolledAt: new Date().toISOString()
    });
  };

  const handleDeleteClass = async (classId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Xóa lớp học',
      message: 'Bạn có chắc chắn muốn xóa lớp học này không?',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'classes', classId));
        } catch (error) {
          console.error("Error deleting class:", error);
        }
      },
      variant: 'danger'
    });
  };

  const handleUnenroll = async (classId: string) => {
    if (!user) return;
    setConfirmModal({
      isOpen: true,
      title: 'Hủy đăng ký',
      message: 'Bạn có chắc chắn muốn hủy đăng ký lớp học này không?',
      onConfirm: async () => {
        try {
          const q = query(
            collection(db, 'enrollments'), 
            where('classId', '==', classId), 
            where('studentId', '==', user.id)
          );
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            await deleteDoc(doc(db, 'enrollments', snapshot.docs[0].id));
          }
        } catch (error) {
          console.error("Error unenrolling:", error);
        }
      },
      variant: 'warning'
    });
  };

  const menuItems = [
    { id: 'classes', icon: <Menu size={22} />, label: 'Lớp học' },
    { id: 'calendar', icon: <Calendar size={22} />, label: 'Lịch' },
    { id: 'notifications', icon: <Bell size={22} />, label: 'Thông báo' },
    { divider: true },
    { id: 'offline', icon: <FileText size={22} />, label: 'Tệp ngoại tuyến' },
    { id: 'archived', icon: <Archive size={22} />, label: 'Lớp học đã lưu trữ' },
    { id: 'history', icon: <BarChart3 size={22} />, label: 'Lịch sử chấm điểm' },
    { divider: true },
    { id: 'settings', icon: <Settings size={22} />, label: 'Cài đặt' },
    { id: 'help', icon: <HelpCircle size={22} />, label: 'Trợ giúp' },
  ];

  const getViewTitle = () => {
    const item = menuItems.find(i => i.id === currentView);
    return item ? item.label : 'EDUNEST Lớp học';
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Top App Bar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 z-40">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsDrawerOpen(true)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Menu size={24} className="text-gray-600" />
          </button>
          <h1 className="text-xl font-semibold text-gray-800">{getViewTitle()}</h1>
        </div>
        
        <div className="flex items-center gap-2">
          {currentView === 'classes' && (
            <button 
              onClick={() => user?.role === 'teacher' ? setIsModalOpen(true) : setIsJoinModalOpen(true)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Plus size={24} className="text-gray-600" />
            </button>
          )}
          <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-100 hover:border-brand-500 transition-all">
            <img src={user?.avatar} alt={user?.name} referrerPolicy="no-referrer" />
          </button>
        </div>
      </header>

      {/* Side Navigation Drawer */}
      <AnimatePresence>
        {isDrawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDrawerOpen(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 bottom-0 w-72 bg-white z-50 shadow-2xl flex flex-col"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center text-white">
                    <Plus size={18} />
                  </div>
                  <span className="font-bold text-lg text-gray-800">EDUNEST</span>
                </div>
                <button onClick={() => setIsDrawerOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X size={20} className="text-gray-500" />
                </button>
              </div>

              <nav className="flex-1 overflow-y-auto py-4">
                {menuItems.map((item, index) => (
                  item.divider ? (
                    <div key={`divider-${index}`} className="my-2 border-t border-gray-100" />
                  ) : (
                    <button
                      key={item.id}
                      onClick={() => {
                        setCurrentView(item.id as ViewType);
                        setIsDrawerOpen(false);
                      }}
                      className={cn(
                        "w-full flex items-center gap-4 px-6 py-3 transition-colors text-sm font-medium",
                        currentView === item.id 
                          ? "text-brand-600 bg-brand-50 border-r-4 border-brand-600" 
                          : "text-gray-600 hover:bg-gray-50"
                      )}
                    >
                      {item.icon}
                      {item.label}
                    </button>
                  )
                ))}
              </nav>

              <div className="p-4 border-t border-gray-100">
                <button 
                  onClick={logout}
                  className="w-full flex items-center gap-4 px-6 py-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors text-sm font-medium"
                >
                  <LogOut size={20} />
                  Đăng xuất
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="pt-20 pb-24 px-4 sm:px-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {currentView === 'classes' && (
              isLoading ? (
                <div className="flex items-center justify-center min-h-[40vh]">
                  <div className="w-12 h-12 border-4 border-brand-100 border-t-brand-600 rounded-full animate-spin" />
                </div>
              ) : classes.length === 0 ? (
                <EmptyState onAction={() => user?.role === 'teacher' ? setIsModalOpen(true) : setIsJoinModalOpen(true)} role={user?.role || 'student'} />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {classes.map((cls: Class) => (
                    <div key={cls.id}>
                      <ClassCard 
                        cls={cls} 
                        onClick={() => navigate(`/class/${cls.id}`)} 
                        onDelete={() => handleDeleteClass(cls.id)}
                        onUnenroll={() => handleUnenroll(cls.id)}
                        isTeacher={cls.teacherId === user?.id}
                      />
                    </div>
                  ))}
                </div>
              )
            )}

            {currentView === 'calendar' && <CalendarView />}
            {currentView === 'notifications' && <NotificationsView />}
            {currentView === 'offline' && <PlaceholderView title="Tệp ngoại tuyến" description="Các tài liệu đã tải về sẽ xuất hiện ở đây để bạn học khi không có mạng." icon={<FileText size={64} />} />}
            {currentView === 'archived' && <PlaceholderView title="Lớp học đã lưu trữ" description="Nơi chứa các lớp học đã kết thúc của bạn." icon={<Archive size={64} />} />}
            {currentView === 'history' && <GradingHistoryView />}
            {currentView === 'settings' && <PlaceholderView title="Cài đặt" description="Chỉnh sửa thông tin cá nhân và cấu hình nhận thông báo." icon={<Settings size={64} />} />}
            {currentView === 'help' && <PlaceholderView title="Trợ giúp" description="Trung tâm hỗ trợ giải đáp thắc mắc về kỹ thuật." icon={<HelpCircle size={64} />} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Action Button */}
      {currentView === 'classes' && (
        <button 
          onClick={() => user?.role === 'teacher' ? setIsModalOpen(true) : setIsJoinModalOpen(true)}
          className="fixed bottom-8 right-8 w-14 h-14 bg-white shadow-xl rounded-2xl flex items-center justify-center text-brand-600 hover:bg-brand-50 transition-all duration-200 active:scale-90 border border-gray-100 group"
        >
          <Plus size={32} className="group-hover:rotate-90 transition-transform duration-300" />
        </button>
      )}

      <CreateClassModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreate={handleCreateClass}
      />

      <JoinClassModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        onJoin={handleJoinClass}
      />

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </div>
  );
}

function ClassCard({ cls, onClick, onDelete, onUnenroll, isTeacher }: { cls: Class, onClick: () => void, onDelete: () => void, onUnenroll: () => void, isTeacher: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="group bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer"
    >
      <div className={cn("h-28 p-4 flex flex-col justify-between relative", cls.bannerColor)}>
        <div className="flex justify-between items-start">
          <h3 className="text-white font-bold text-xl leading-tight group-hover:underline">{cls.name}</h3>
          <div className="relative group/menu">
            <button 
              onClick={(e) => {
                e.stopPropagation();
              }} 
              className="p-1 hover:bg-white/20 rounded-full text-white transition-colors"
            >
              <MoreVertical size={20} />
            </button>
            <div className="absolute right-0 top-full mt-1 w-40 bg-white rounded-xl shadow-xl border border-gray-100 py-1 opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-50">
              {isTeacher ? (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete();
                  }}
                  className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium"
                >
                  Xóa lớp học
                </button>
              ) : (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onUnenroll();
                  }}
                  className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium"
                >
                  Hủy đăng ký
                </button>
              )}
            </div>
          </div>
        </div>
        <p className="text-white/80 text-sm font-medium">{cls.section}</p>
        <div className="absolute top-4 right-4 flex items-center gap-2 bg-white/20 backdrop-blur-md px-2 py-1 rounded-lg text-white text-[10px] font-bold">
          <Hash size={12} />
          {cls.classCode}
        </div>
        <div className="absolute -bottom-6 right-4 w-12 h-12 rounded-full border-2 border-white overflow-hidden bg-white shadow-md">
          <div className="w-full h-full bg-gray-100 flex items-center justify-center text-gray-400">
            <User size={24} />
          </div>
        </div>
      </div>
      <div className="p-4 pt-8 flex flex-col gap-4">
        <div className="flex items-center gap-2 text-gray-500 text-sm">
          <User size={16} />
          <span>{cls.teacherName}</span>
        </div>
        <div className="border-t border-gray-50 pt-4 flex justify-end gap-2">
          <button onClick={(e) => e.stopPropagation()} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors">
            <Calendar size={20} />
          </button>
          <button onClick={(e) => e.stopPropagation()} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors">
            <Folder size={20} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function EmptyState({ onAction, role }: { onAction: () => void, role: string }) {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center text-center">
      <div className="relative mb-8">
        <div className="w-64 h-64 mx-auto bg-brand-50 rounded-full flex items-center justify-center">
          <motion.div
            animate={{ 
              y: [0, -10, 0],
              rotate: [0, 2, -2, 0]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            <Folder size={120} className="text-brand-200" />
          </motion.div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <Plus size={48} className="text-brand-400 opacity-50" />
        </div>
      </div>

      <p className="text-gray-500 mb-2">
        Bạn không thấy các lớp của mình? <button className="text-brand-600 font-medium hover:underline">Thử tài khoản khác</button>
      </p>
      <h2 className="text-2xl font-bold text-gray-800 mb-8">Hãy thêm một lớp học để bắt đầu</h2>

      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        {role === 'teacher' ? (
          <button onClick={onAction} className="btn-outline">
            Tạo lớp học
          </button>
        ) : (
          <button onClick={onAction} className="btn-primary">
            Tham gia lớp học
          </button>
        )}
      </div>
    </div>
  );
}

function GradingHistoryView() {
  const history = [
    { id: 1, student: 'Nguyễn Văn A', class: 'Lớp học 123213', assignment: 'Bài tập 1: React Cơ bản', grade: 9.5, date: '08/04/2024' },
    { id: 2, student: 'Trần Thị B', class: 'Lớp học 123213', assignment: 'Bài tập 1: React Cơ bản', grade: 8.0, date: '08/04/2024' },
    { id: 3, student: 'Lê Văn C', class: 'Lớp học 123213', assignment: 'Bài tập 2: Tailwind CSS', grade: 10, date: '09/04/2024' },
    { id: 4, student: 'Phạm Minh D', class: 'Lớp học 123213', assignment: 'Bài tập 1: React Cơ bản', grade: 7.5, date: '07/04/2024' },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Lịch sử chấm điểm</h2>
          <p className="text-gray-500">Xem lại kết quả học tập của học sinh qua các lớp.</p>
        </div>
        <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-600">
          <ExternalLink size={20} />
        </button>
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Học sinh</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Lớp học</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Bài tập</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Điểm số</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Ngày chấm</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {history.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center text-brand-600 font-bold text-xs">
                        {item.student.charAt(0)}
                      </div>
                      <span className="font-medium text-gray-800">{item.student}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{item.class}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{item.assignment}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-xs font-bold",
                      item.grade >= 8 ? "bg-emerald-50 text-emerald-600" : 
                      item.grade >= 5 ? "bg-amber-50 text-amber-600" : "bg-rose-50 text-rose-600"
                    )}>
                      {item.grade.toFixed(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{item.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function PlaceholderView({ title, description, icon, actionText }: { title: string, description: string, icon: React.ReactNode, actionText?: string }) {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center max-w-md mx-auto">
      <div className="w-32 h-32 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mb-8">
        {icon}
      </div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">{title}</h2>
      <p className="text-gray-500 mb-8 leading-relaxed">{description}</p>
      {actionText && (
        <button className="btn-primary flex items-center gap-2">
          <ExternalLink size={20} />
          {actionText}
        </button>
      )}
    </div>
  );
}

function CalendarView() {
  const days = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'CN'];
  const events = [
    { id: 1, title: 'Hạn chót Bài tập 1', time: '23:59', date: '10/04', type: 'deadline', color: 'text-rose-600 bg-rose-50' },
    { id: 2, title: 'Kiểm tra giữa kỳ', time: '08:00', date: '12/04', type: 'exam', color: 'text-amber-600 bg-amber-50' },
    { id: 3, title: 'Hạn chót Bài tập 2', time: '23:59', date: '15/04', type: 'deadline', color: 'text-rose-600 bg-rose-50' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Tháng 4, 2024</h2>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-600">Trước</button>
          <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 font-bold">Hôm nay</button>
          <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-600">Sau</button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px bg-gray-200 border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        {days.map(day => (
          <div key={day} className="bg-gray-50 p-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider">
            {day}
          </div>
        ))}
        {Array.from({ length: 35 }).map((_, i) => {
          const dayNum = (i + 1) % 31 || 31;
          const isToday = dayNum === 4;
          return (
            <div key={i} className="bg-white min-h-[120px] p-2 hover:bg-gray-50 transition-colors">
              <span className={cn(
                "inline-flex items-center justify-center w-7 h-7 text-sm font-medium rounded-full mb-1",
                isToday ? "bg-brand-600 text-white" : "text-gray-700"
              )}>
                {dayNum}
              </span>
              {isToday && (
                <div className="space-y-1">
                  <div className="text-[10px] p-1 bg-rose-50 text-rose-600 rounded font-bold truncate">Hạn chót BT1</div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
        <h3 className="font-bold text-gray-800 mb-4">Sắp tới</h3>
        <div className="space-y-4">
          {events.map(event => (
            <div key={event.id} className="flex items-center justify-between p-4 rounded-xl border border-gray-50 hover:border-brand-100 transition-all">
              <div className="flex items-center gap-4">
                <div className={cn("px-3 py-1 rounded-lg text-xs font-bold", event.color)}>
                  {event.date}
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{event.title}</h4>
                  <p className="text-xs text-gray-500">{event.time}</p>
                </div>
              </div>
              <button className="text-brand-600 text-sm font-bold hover:underline">Chi tiết</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function NotificationsView() {
  const notifications = [
    { id: 1, title: 'Bài tập mới', content: 'Giảng viên EDUNEST đã đăng bài tập mới: Bài tập 2: Xây dựng giao diện với Tailwind', time: '2 giờ trước', icon: <FileText size={20} />, color: 'bg-blue-50 text-blue-600', unread: true },
    { id: 2, title: 'Thông báo lớp học', content: 'Chào mừng các em đến với lớp học! Hãy kiểm tra phần bài tập để bắt đầu nhé.', time: '5 giờ trước', icon: <Bell size={20} />, color: 'bg-brand-50 text-brand-600', unread: true },
    { id: 3, title: 'Điểm số mới', content: 'Bài tập 1 của bạn đã được chấm điểm.', time: '1 ngày trước', icon: <CheckCircle2 size={20} />, color: 'bg-emerald-50 text-emerald-600', unread: false },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-800">Thông báo</h2>
        <button className="text-brand-600 text-sm font-bold hover:underline">Đánh dấu tất cả là đã đọc</button>
      </div>

      <div className="space-y-3">
        {notifications.map(notif => (
          <div key={notif.id} className={cn(
            "p-4 rounded-2xl border transition-all flex gap-4 items-start",
            notif.unread ? "bg-white border-brand-100 shadow-sm" : "bg-gray-50 border-transparent opacity-70"
          )}>
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", notif.color)}>
              {notif.icon}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start mb-1">
                <h4 className="font-bold text-gray-800">{notif.title}</h4>
                <span className="text-[10px] text-gray-400 font-medium">{notif.time}</span>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed">{notif.content}</p>
            </div>
            {notif.unread && <div className="w-2 h-2 bg-brand-600 rounded-full mt-2" />}
          </div>
        ))}
      </div>
    </div>
  );
}
