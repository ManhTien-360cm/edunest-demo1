import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  ArrowLeft, 
  MoreVertical, 
  Plus, 
  MessageSquare, 
  FileText, 
  Users, 
  BarChart3,
  Send,
  Paperclip,
  CheckCircle2,
  Clock,
  ChevronRight,
  Upload,
  Folder,
  User as UserIcon,
  Settings,
  X,
  Eye,
  Download
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Class, Assignment, Submission, Post, Role, Topic } from '../types';
import { sendSubmissionNotification, sendGradingNotification } from '../lib/email';
import CreateAssignmentModal from '../components/CreateAssignmentModal';
import ConfirmModal from '../components/ConfirmModal';
import { 
  doc, 
  getDoc, 
  getDocs,
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc,
  deleteDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';

type Tab = 'stream' | 'classwork' | 'people' | 'grades';

export default function ClassDetail() {
  const { classId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('stream');
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [teacherEmail, setTeacherEmail] = useState<string>('');
  const [currentClass, setCurrentClass] = useState<Class | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [isAssignmentModalOpen, setIsAssignmentModalOpen] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    variant?: 'danger' | 'warning' | 'info';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    if (!classId) return;
    
    const fetchClass = async () => {
      setIsLoading(true);
      try {
        const cDoc = await getDoc(doc(db, 'classes', classId));
        if (cDoc.exists()) {
          const classData = { id: cDoc.id, ...cDoc.data() } as Class;
          setCurrentClass(classData);
          setTeacherEmail(classData.teacherEmail || '');
        }
      } catch (error) {
        console.error("Error fetching class:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchClass();

    // Fetch topics
    const topicsQuery = query(collection(db, 'topics'), where('classId', '==', classId));
    const unsubTopics = onSnapshot(topicsQuery, (snapshot) => {
      setTopics(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Topic)));
    });

    return () => unsubTopics();
  }, [classId]);

  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    if (!classId) return;
    const q = query(collection(db, 'posts'), where('classId', '==', classId));
    const unsub = onSnapshot(q, (snapshot) => {
      setPosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Post)));
    });
    return () => unsub();
  }, [classId]);

  const [assignments, setAssignments] = useState<Assignment[]>([]);

  useEffect(() => {
    if (!classId) return;
    
    // Fetch assignments
    const assignmentsQuery = query(collection(db, 'assignments'), where('classId', '==', classId));
    const unsubAssignments = onSnapshot(assignmentsQuery, (snapshot) => {
      setAssignments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Assignment)));
    });

    return () => unsubAssignments();
  }, [classId]);

  const handleCreateAssignment = async (data: any) => {
    if (!classId || !user) return;
    
    // Sanitize data to remove undefined values (Firestore doesn't support them)
    const sanitizedData = { ...data };
    Object.keys(sanitizedData).forEach(key => {
      if (sanitizedData[key] === undefined) {
        sanitizedData[key] = null;
      }
    });

    try {
      const assignmentRef = await addDoc(collection(db, 'assignments'), {
        ...sanitizedData,
        classId,
        createdAt: new Date().toISOString()
      });

      // Create a post on the stream about the new assignment
      await addDoc(collection(db, 'posts'), {
        classId,
        authorName: user.name,
        authorAvatar: user.avatar || '',
        content: `Đã đăng một bài tập mới: ${data.title}`,
        createdAt: new Date().toISOString(),
        assignmentId: assignmentRef.id // Link to assignment
      });

    } catch (error) {
      console.error("Error creating assignment:", error);
    }
  };

  const handleDeleteClass = async () => {
    if (!classId || !currentClass) return;
    
    setConfirmModal({
      isOpen: true,
      title: 'Xóa lớp học',
      message: 'Bạn có chắc chắn muốn xóa lớp học này không? Hành động này không thể hoàn tác.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'classes', classId));
          navigate('/');
        } catch (error) {
          console.error("Error deleting class:", error);
        }
      },
      variant: 'danger'
    });
  };

  const handleUnenroll = async () => {
    if (!classId || !user) return;
    
    setConfirmModal({
      isOpen: true,
      title: 'Hủy đăng ký',
      message: 'Bạn có chắc chắn muốn hủy đăng ký lớp học này không?',
      onConfirm: async () => {
        try {
          const q = query(
            collection(db, 'enrollments'), 
            where('classId', '==', classId), 
            where('studentId', '==', user.id)
          );
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            await deleteDoc(doc(db, 'enrollments', snapshot.docs[0].id));
            navigate('/');
          }
        } catch (error) {
          console.error("Error unenrolling:", error);
        }
      },
      variant: 'warning'
    });
  };

  const [submissions, setSubmissions] = useState<Submission[]>([]);

  useEffect(() => {
    if (!classId) return;
    const q = query(collection(db, 'submissions'), where('classId', '==', classId));
    const unsub = onSnapshot(q, (snapshot) => {
      setSubmissions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Submission)));
    });
    return () => unsub();
  }, [classId]);

  const handleDeleteAssignment = async (assignmentId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Xóa bài tập',
      message: 'Bạn có chắc chắn muốn xóa bài tập này không?',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'assignments', assignmentId));
        } catch (error) {
          console.error("Error deleting assignment:", error);
        }
      },
      variant: 'danger'
    });
  };

  const handleDeleteTopic = async (topicId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Xóa chủ đề',
      message: 'Bạn có chắc chắn muốn xóa chủ đề này không? Các bài tập trong chủ đề này sẽ trở thành không có chủ đề.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'topics', topicId));
          const q = query(collection(db, 'assignments'), where('topicId', '==', topicId));
          const snapshot = await getDocs(q);
          const batch = snapshot.docs.map(d => updateDoc(doc(db, 'assignments', d.id), { topicId: null }));
          await Promise.all(batch);
        } catch (error) {
          console.error("Error deleting topic:", error);
        }
      },
      variant: 'danger'
    });
  };

  const handleBack = () => {
    if (selectedAssignment) {
      setSelectedAssignment(null);
    } else {
      navigate('/');
    }
  };

  const tabs = [
    { id: 'stream', label: 'Bảng tin', icon: <MessageSquare size={20} /> },
    { id: 'classwork', label: 'Bài tập trên lớp', icon: <FileText size={20} /> },
    { id: 'people', label: 'Mọi người', icon: <Users size={20} /> },
    ...(user?.role === 'teacher' ? [{ id: 'grades', label: 'Số điểm', icon: <BarChart3 size={20} /> }] : [])
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-brand-100 border-t-brand-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!currentClass) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4 text-center">
        <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mb-6">
          <X size={40} />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Không tìm thấy lớp học</h2>
        <p className="text-gray-500 mb-8">Lớp học không tồn tại hoặc bạn không có quyền truy cập.</p>
        <button onClick={() => navigate('/')} className="btn-primary">Quay lại trang chủ</button>
      </div>
    );
  }

  const role = user?.role === 'teacher' && currentClass.teacherId === user.id ? 'teacher' : 'student';
  const teacherName = currentClass.teacherName;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-100 flex items-center px-4 z-40">
        <div className="flex items-center gap-4 w-full">
          <button onClick={handleBack} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          
          {!selectedAssignment && (
            <div className="flex-1 flex justify-center">
              <div className="flex bg-gray-50 p-1 rounded-xl">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as Tab)}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                      activeTab === tab.id 
                        ? "bg-white text-brand-600 shadow-sm" 
                        : "text-gray-500 hover:text-gray-700"
                    )}
                  >
                    {tab.icon}
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {selectedAssignment && (
            <div className="flex-1">
              <h2 className="font-bold text-gray-800 truncate">{selectedAssignment.title}</h2>
            </div>
          )}

          <div className="flex items-center gap-2">
            <div className="relative group">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Settings size={22} className="text-gray-600" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                {user?.role === 'teacher' ? (
                  <button 
                    onClick={handleDeleteClass}
                    className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium flex items-center gap-2"
                  >
                    <X size={16} />
                    Xóa lớp học
                  </button>
                ) : (
                  <button 
                    onClick={handleUnenroll}
                    className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium flex items-center gap-2"
                  >
                    <X size={16} />
                    Hủy đăng ký
                  </button>
                )}
              </div>
            </div>
            <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-100">
              <img src={user?.avatar} alt={user?.name} referrerPolicy="no-referrer" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="pt-20 pb-12 max-w-5xl mx-auto px-4">
        <AnimatePresence mode="wait">
          {selectedAssignment ? (
            <AssignmentDetailView 
              assignment={selectedAssignment} 
              role={user?.role || 'student'} 
              submissions={submissions}
              setSubmissions={setSubmissions}
              teacherName={currentClass.teacherName}
              teacherEmail={teacherEmail || currentClass.teacherEmail}
            />
          ) : (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'stream' && (
                <StreamTab currentClass={currentClass} posts={posts} setPosts={setPosts} user={user} />
              )}
              {activeTab === 'classwork' && (
                <ClassworkTab 
                  assignments={assignments} 
                  topics={topics}
                  onSelectAssignment={setSelectedAssignment} 
                  role={role}
                  classId={classId}
                  onCreateAssignment={() => setIsAssignmentModalOpen(true)}
                  onDeleteAssignment={handleDeleteAssignment}
                  onDeleteTopic={handleDeleteTopic}
                />
              )}
              {activeTab === 'people' && (
                <PeopleTab currentClass={currentClass} />
              )}
              {activeTab === 'grades' && (
                <GradesTab assignments={assignments} submissions={submissions} setSubmissions={setSubmissions} user={user} />
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <CreateAssignmentModal
        isOpen={isAssignmentModalOpen}
        onClose={() => setIsAssignmentModalOpen(false)}
        onCreate={handleCreateAssignment}
        topics={topics}
      />

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </div>
  );
}

// --- Tab Components ---

function StreamTab({ currentClass, posts, setPosts, user }: any) {
  const [newPost, setNewPost] = useState('');

  const handlePost = async () => {
    if (!newPost.trim()) return;
    try {
      await addDoc(collection(db, 'posts'), {
        classId: currentClass.id,
        authorName: user?.name || 'User',
        authorAvatar: user?.avatar || '',
        content: newPost,
        createdAt: new Date().toISOString()
      });
      setNewPost('');
    } catch (error) {
      console.error("Error creating post:", error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className={cn("h-48 rounded-2xl p-8 flex flex-col justify-end relative overflow-hidden", currentClass.bannerColor)}>
        <div className="absolute top-0 right-0 p-4 opacity-20">
          <Plus size={120} className="rotate-45" />
        </div>
        <h1 className="text-3xl font-bold text-white mb-1">{currentClass.name}</h1>
        <p className="text-white/80 font-medium">{currentClass.section}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Info */}
        <div className="hidden lg:block space-y-4">
          <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-2">Sắp đến hạn</h3>
            <p className="text-sm text-gray-500 mb-4">Tuyệt vời! Không có bài tập nào sắp đến hạn.</p>
            <button className="text-brand-600 text-sm font-bold hover:underline">Xem tất cả</button>
          </div>
        </div>

        {/* Feed */}
        <div className="lg:col-span-3 space-y-6">
          {/* Post Input */}
          <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
              <img src={user?.avatar} alt="User" referrerPolicy="no-referrer" />
            </div>
            <div className="flex-1 space-y-3">
              <textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="Thông báo nội dung nào đó cho lớp học của bạn"
                className="w-full p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-brand-500/20 resize-none min-h-[100px] outline-none transition-all"
              />
              <div className="flex justify-between items-center">
                <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors">
                  <Paperclip size={20} />
                </button>
                <div className="flex gap-2">
                  <button onClick={() => setNewPost('')} className="px-4 py-2 text-gray-500 font-medium hover:bg-gray-50 rounded-lg transition-colors">Hủy</button>
                  <button onClick={handlePost} className="btn-primary px-6 py-2 rounded-lg text-sm">Đăng</button>
                </div>
              </div>
            </div>
          </div>

          {/* Posts */}
          {posts.map((post: Post) => (
            <div key={post.id} className="bg-white border border-gray-100 rounded-xl p-6 shadow-sm space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-100">
                  {post.authorAvatar ? (
                    <img src={post.authorAvatar} alt={post.authorName} referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <UserIcon size={20} />
                    </div>
                  )}
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 leading-none mb-1">{post.authorName}</h4>
                  <p className="text-xs text-gray-400">{new Date(post.createdAt).toLocaleDateString('vi-VN')}</p>
                </div>
                <button className="ml-auto p-2 hover:bg-gray-100 rounded-full text-gray-400">
                  <MoreVertical size={20} />
                </button>
              </div>
              <p className="text-gray-700 whitespace-pre-wrap">{post.content}</p>
              <div className="border-t border-gray-50 pt-4">
                <button className="text-sm text-gray-500 font-medium hover:text-brand-600 transition-colors">Thêm nhận xét lớp học...</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface ClassworkTabProps {
  assignments: Assignment[];
  topics: Topic[];
  onSelectAssignment: (assignment: Assignment) => void;
  role: Role;
  classId: string;
  onCreateAssignment: () => void;
  onDeleteAssignment: (id: string) => void;
  onDeleteTopic: (id: string) => void;
}

function ClassworkTab({ 
  assignments, 
  topics, 
  onSelectAssignment, 
  role, 
  classId, 
  onCreateAssignment,
  onDeleteAssignment,
  onDeleteTopic
}: ClassworkTabProps) {
  const [isAddingTopic, setIsAddingTopic] = useState(false);
  const [topicName, setTopicName] = useState('');

  const handleCreateTopic = async () => {
    if (!topicName.trim()) return;
    try {
      await addDoc(collection(db, 'topics'), {
        classId,
        name: topicName.trim(),
        createdAt: new Date().toISOString()
      });
      setTopicName('');
      setIsAddingTopic(false);
    } catch (error) {
      console.error("Error creating topic:", error);
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Bài tập trên lớp</h2>
        {role === 'teacher' && (
          <div className="flex gap-2">
            <button 
              onClick={() => setIsAddingTopic(true)}
              className="btn-outline flex items-center gap-2"
            >
              <Folder size={20} />
              Thêm chủ đề
            </button>
            <button 
              onClick={onCreateAssignment}
              className="btn-primary flex items-center gap-2"
            >
              <Plus size={20} />
              Tạo bài tập
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {isAddingTopic && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-gray-50 p-6 rounded-2xl border-2 border-dashed border-gray-200"
          >
            <h3 className="font-bold text-gray-800 mb-4">Tạo chủ đề mới</h3>
            <div className="flex gap-3">
              <input
                type="text"
                value={topicName}
                onChange={(e) => setTopicName(e.target.value)}
                placeholder="Tên chủ đề (ví dụ: Chương 1, Tài liệu tham khảo...)"
                className="flex-1 px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500/20 outline-none"
              />
              <button onClick={() => setIsAddingTopic(false)} className="px-4 py-2 text-gray-500 font-medium">Hủy</button>
              <button onClick={handleCreateTopic} className="btn-primary px-6">Tạo</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Topics and Assignments */}
      <div className="space-y-12">
        {/* Uncategorized Assignments */}
        {assignments.filter((a: Assignment) => !a.topicId).length > 0 && (
          <div className="space-y-4">
            <div className="space-y-4">
              {assignments.filter((a: Assignment) => !a.topicId).map((assignment: Assignment) => (
                <AssignmentItem 
                  key={assignment.id} 
                  assignment={assignment} 
                  onClick={() => onSelectAssignment(assignment)}
                  onDelete={() => onDeleteAssignment(assignment.id)}
                  role={role}
                />
              ))}
            </div>
          </div>
        )}

        {/* Topics */}
        {topics.map((topic: Topic) => (
          <div key={topic.id} className="space-y-6">
            <div className="flex items-center justify-between border-b-2 border-brand-600 pb-2">
              <h3 className="text-xl font-bold text-brand-600 flex items-center gap-2">
                <Folder size={24} />
                {topic.name}
              </h3>
              {role === 'teacher' && (
                <div className="relative group/topic">
                  <button className="p-2 hover:bg-brand-50 rounded-full text-brand-600">
                    <MoreVertical size={20} />
                  </button>
                  <div className="absolute right-0 top-full mt-1 w-32 bg-white rounded-xl shadow-xl border border-gray-100 py-1 opacity-0 invisible group-hover/topic:opacity-100 group-hover/topic:visible transition-all z-10">
                    <button 
                      onClick={() => onDeleteTopic(topic.id)}
                      className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium"
                    >
                      Xóa chủ đề
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div className="space-y-4">
              {assignments.filter((a: Assignment) => a.topicId === topic.id).length === 0 ? (
                <p className="text-sm text-gray-400 italic px-4">Chưa có bài tập nào trong chủ đề này.</p>
              ) : (
                assignments.filter((a: Assignment) => a.topicId === topic.id).map((assignment: Assignment) => (
                  <AssignmentItem 
                    key={assignment.id} 
                    assignment={assignment} 
                    onClick={() => onSelectAssignment(assignment)}
                    onDelete={() => onDeleteAssignment(assignment.id)}
                    role={role}
                  />
                ))
              )}
            </div>
          </div>
        ))}

        {topics.length === 0 && assignments.length === 0 && (
          <div className="text-center py-20 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
            <FileText size={64} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">Chưa có nội dung nào</h3>
            <p className="text-gray-500">Giáo viên chưa đăng bài tập hoặc tài liệu nào.</p>
          </div>
        )}
      </div>
    </div>
  );
}

interface AssignmentItemProps {
  assignment: Assignment;
  onClick: () => void;
  onDelete: () => void;
  role: Role;
}

const AssignmentItem: React.FC<AssignmentItemProps> = ({ assignment, onClick, onDelete, role }) => {
  return (
    <div 
      className="group bg-white border border-gray-100 rounded-xl p-4 flex items-center gap-4 hover:shadow-md transition-all cursor-pointer relative"
      onClick={onClick}
    >
      <div className="w-10 h-10 bg-brand-50 rounded-full flex items-center justify-center text-brand-600 group-hover:bg-brand-600 group-hover:text-white transition-colors">
        <FileText size={20} />
      </div>
      <div className="flex-1">
        <h4 className="font-bold text-gray-800 group-hover:text-brand-600 transition-colors">{assignment.title}</h4>
        <p className="text-xs text-gray-400">Đã đăng {new Date(assignment.createdAt).toLocaleDateString('vi-VN')}</p>
      </div>
      <div className="text-right hidden sm:block">
        <p className="text-xs text-gray-400 mb-1">Hạn chót</p>
        <p className="text-sm font-medium text-gray-600">{new Date(assignment.dueDate).toLocaleDateString('vi-VN')}</p>
      </div>
      
      {role === 'teacher' && (
        <div className="relative group/item ml-2" onClick={(e) => e.stopPropagation()}>
          <button className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors">
            <MoreVertical size={18} />
          </button>
          <div className="absolute right-0 top-full mt-1 w-32 bg-white rounded-xl shadow-xl border border-gray-100 py-1 opacity-0 invisible group-hover/item:opacity-100 group-hover/item:visible transition-all z-10">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium"
            >
              Xóa bài tập
            </button>
          </div>
        </div>
      )}
      
      <ChevronRight size={20} className="text-gray-300 group-hover:text-brand-600 transition-colors" />
    </div>
  );
}

function PeopleTab({ currentClass }: any) {
  return (
    <div className="space-y-12 max-w-3xl mx-auto">
      <section>
        <div className="flex justify-between items-center border-b-2 border-brand-600 pb-2 mb-6">
          <h2 className="text-2xl font-bold text-brand-600">Giáo viên</h2>
          <button className="p-2 hover:bg-brand-50 rounded-full text-brand-600">
            <Plus size={24} />
          </button>
        </div>
        <div className="flex items-center gap-4 px-4">
          <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
            <UserIcon size={20} />
          </div>
          <span className="font-medium text-gray-800">{currentClass.teacherName}</span>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center border-b-2 border-brand-600 pb-2 mb-6">
          <h2 className="text-2xl font-bold text-brand-600">Bạn học</h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-500">12 học sinh</span>
            <button className="p-2 hover:bg-brand-50 rounded-full text-brand-600">
              <Plus size={24} />
            </button>
          </div>
        </div>
        <div className="space-y-4">
          {['Nguyễn Văn A', 'Trần Thị B', 'Lê Văn C', 'Phạm Thị D'].map((name) => (
            <div key={name} className="flex items-center gap-4 px-4 py-2 hover:bg-gray-50 rounded-xl transition-colors">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                <UserIcon size={20} />
              </div>
              <span className="font-medium text-gray-800">{name}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function GradesTab({ assignments, submissions, setSubmissions, user }: any) {
  const handleGradeChange = async (studentName: string, assignmentId: string, grade: string) => {
    const gradeNum = parseInt(grade);
    if (isNaN(gradeNum)) return;

    const submission = submissions.find((s: any) => s.studentName === studentName && s.assignmentId === assignmentId);
    if (!submission) return;

    try {
      await updateDoc(doc(db, 'submissions', submission.id), {
        grade: gradeNum,
        status: 'graded'
      });

      // Send email notification if submission exists and has email
      if (submission.studentEmail) {
        const assignment = assignments.find((a: any) => a.id === assignmentId);
        await sendGradingNotification(
          submission.studentEmail,
          submission.studentName,
          assignment?.title || 'Bài tập',
          gradeNum,
          user?.name || 'Giáo viên'
        );
      }
    } catch (error) {
      console.error("Error updating grade:", error);
    }
  };

  const students = Array.from(new Set(submissions.map(s => s.studentName)));

  return (
    <div className="space-y-8 overflow-x-auto">
      <h2 className="text-2xl font-bold text-gray-800">Số điểm</h2>
      <table className="w-full border-collapse min-w-[800px]">
        <thead>
          <tr className="bg-gray-50">
            <th className="p-4 text-left border border-gray-200 font-bold text-gray-600">Học sinh</th>
            {assignments.map((a: any) => (
              <th key={a.id} className="p-4 text-center border border-gray-200 min-w-[150px]">
                <div className="text-sm font-bold text-gray-800 mb-1">{a.title}</div>
                <div className="text-xs font-medium text-gray-400">/{a.points}</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {students.length === 0 ? (
            <tr>
              <td colSpan={assignments.length + 1} className="p-8 text-center text-gray-400 italic">
                Chưa có dữ liệu điểm số.
              </td>
            </tr>
          ) : (
            students.map((student: any) => (
              <tr key={student as string} className="hover:bg-gray-50 transition-colors">
                <td className="p-4 border border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                      <UserIcon size={16} />
                    </div>
                    <span className="font-medium text-gray-800">{student as string}</span>
                  </div>
                </td>
                {assignments.map((a: any) => {
                  const sub = submissions.find((s: any) => s.assignmentId === a.id && s.studentName === student);
                  return (
                    <td key={a.id} className="p-4 border border-gray-200 text-center">
                      {sub ? (
                        <div className="flex flex-col items-center gap-1">
                          <input 
                            type="number"
                            className="w-16 p-1 text-center border border-gray-200 rounded focus:ring-2 focus:ring-brand-500/20 outline-none font-bold text-brand-600"
                            defaultValue={sub.grade}
                            onBlur={(e) => handleGradeChange(student as string, a.id, e.target.value)}
                          />
                          <span className="text-[10px] text-gray-400 uppercase font-bold">{sub.status === 'graded' ? 'Đã trả' : 'Đã nộp'}</span>
                        </div>
                      ) : (
                        <span className="text-gray-300">--</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

// --- Detail View ---

interface AssignmentDetailViewProps {
  assignment: Assignment;
  role: Role;
  submissions: Submission[];
  setSubmissions: React.Dispatch<React.SetStateAction<Submission[]>>;
  teacherName: string;
  teacherEmail?: string;
}

function AssignmentDetailView({ assignment, role, submissions, setSubmissions, teacherName, teacherEmail: teacherEmailProp }: AssignmentDetailViewProps) {
  const { user } = useAuth();
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [gradingValues, setGradingValues] = useState<Record<string, number>>({});
  const [confirmGrade, setConfirmGrade] = useState<{ id: string, grade: number } | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [viewingSubmission, setViewingSubmission] = useState<Submission | null>(null);

  const mySubmission = submissions.find((s: Submission) => s.assignmentId === assignment.id && s.studentId === user?.id);

  const handleTurnIn = async () => {
    setIsSubmitting(true);
    
    // In a real app, we would fetch the teacher's email from Firestore if not available
    let teacherEmail = teacherEmailProp;
    if (!teacherEmail) {
      try {
        // This is a fallback if the prop is missing
        const teacherDoc = await getDoc(doc(db, 'users', 'teacher-1')); // Mock teacher ID
        if (teacherDoc.exists()) {
          teacherEmail = teacherDoc.data().email;
        }
      } catch (error) {
        console.error("Error fetching teacher email:", error);
      }
    }

    try {
      const newSubData = {
        assignmentId: assignment.id,
        classId: assignment.classId,
        studentId: user?.id || '1',
        studentName: user?.name || 'User',
        studentEmail: user?.email,
        status: 'turned-in',
        fileName: file?.name || 'document.pdf',
        submittedAt: new Date().toISOString()
      };
      
      await addDoc(collection(db, 'submissions'), newSubData);
      setIsSubmitting(false);

      // Send email notification to teacher
      if (teacherEmail) {
        await sendSubmissionNotification(
          teacherEmail,
          teacherName,
          user?.name || 'Học sinh',
          assignment.title
        );
      }
    } catch (error) {
      console.error("Error submitting assignment:", error);
      setIsSubmitting(false);
    }
  };

  const handleGradeSubmission = async (submissionId: string) => {
    const grade = gradingValues[submissionId];
    if (grade === undefined) return;

    const submission = submissions.find(s => s.id === submissionId);
    if (!submission) return;

    setConfirmGrade({ id: submissionId, grade });
  };

  const processGrading = async () => {
    if (!confirmGrade) return;
    const { id: submissionId, grade } = confirmGrade;
    const submission = submissions.find(s => s.id === submissionId);
    if (!submission) return;

    try {
      await updateDoc(doc(db, 'submissions', submissionId), {
        grade,
        status: 'graded'
      });

      setConfirmGrade(null);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);

      // Send email notification to student
      if (submission.studentEmail) {
        await sendGradingNotification(
          submission.studentEmail,
          submission.studentName,
          assignment.title,
          grade,
          user?.name || 'Giáo viên'
        );
      }
    } catch (error) {
      console.error("Error grading submission:", error);
    }
  };

  if (role === 'teacher') {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-20 left-1/2 -translate-x-1/2 bg-emerald-600 text-white px-6 py-3 rounded-full shadow-lg z-[100] flex items-center gap-2"
            >
              <CheckCircle2 size={20} />
              <span className="font-bold">Đã chấm điểm thành công!</span>
            </motion.div>
          )}

          {viewingSubmission && (
            <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto"
              >
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-brand-50 rounded-full flex items-center justify-center text-brand-600 font-bold">
                      {viewingSubmission.studentName.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{viewingSubmission.studentName}</h3>
                      <p className="text-sm text-gray-500">Nộp vào: {new Date(viewingSubmission.submittedAt!).toLocaleString('vi-VN')}</p>
                    </div>
                  </div>
                  <button onClick={() => setViewingSubmission(null)} className="p-2 hover:bg-gray-100 rounded-full">
                    <X size={24} className="text-gray-400" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                    <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                      <FileText size={18} className="text-brand-600" />
                      Tệp tin đã nộp
                    </h4>
                    <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-rose-50 rounded-lg flex items-center justify-center text-rose-600">
                          <FileText size={20} />
                        </div>
                        <div>
                          <p className="font-medium text-gray-800">{viewingSubmission.fileName}</p>
                          <p className="text-xs text-gray-500">2.4 MB • PDF</p>
                        </div>
                      </div>
                      <button className="p-2 text-brand-600 hover:bg-brand-50 rounded-lg transition-colors">
                        <Download size={20} />
                      </button>
                    </div>
                  </div>

                  <div className="p-6 bg-brand-50 rounded-2xl">
                    <h4 className="font-bold text-brand-800 mb-2">Nội dung bài làm</h4>
                    <p className="text-brand-700 leading-relaxed">
                      Đây là nội dung mô phỏng của bài làm. Trong thực tế, bạn có thể xem trực tiếp nội dung văn bản hoặc hình ảnh mà học sinh đã tải lên tại đây.
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex justify-end">
                  <button
                    onClick={() => setViewingSubmission(null)}
                    className="btn-primary px-8"
                  >
                    Đóng
                  </button>
                </div>
              </motion.div>
            </div>
          )}

          {confirmGrade && (
            <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl"
              >
                <h3 className="text-xl font-bold text-gray-900 mb-2">Xác nhận chấm điểm</h3>
                <p className="text-gray-500 mb-6">
                  Bạn có chắc chắn muốn chấm <span className="font-bold text-brand-600">{confirmGrade.grade} điểm</span> cho học sinh này không?
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setConfirmGrade(null)}
                    className="flex-1 py-3 text-gray-600 font-bold hover:bg-gray-50 rounded-xl transition-colors"
                  >
                    Hủy
                  </button>
                  <button
                    onClick={processGrading}
                    className="flex-1 btn-primary py-3"
                  >
                    Xác nhận
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center gap-4 border-b border-gray-100 pb-6">
            <div className="w-12 h-12 bg-brand-50 rounded-full flex items-center justify-center text-brand-600">
              <FileText size={24} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-1">{assignment.title}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-500">
                <span>{teacherName}</span>
                <span>•</span>
                <span>{new Date(assignment.createdAt).toLocaleDateString('vi-VN')}</span>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 p-6 rounded-2xl">
            <h3 className="font-bold text-gray-800 mb-2">Hướng dẫn</h3>
            <p className="text-gray-700 leading-relaxed">{assignment.description}</p>
          </div>
          
          <div className="pt-8">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Bài làm của học viên</h3>
            <div className="space-y-4">
              {submissions.filter((s: Submission) => s.assignmentId === assignment.id).length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                  <FileText size={48} className="mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">Chưa có học sinh nào nộp bài.</p>
                </div>
              ) : (
                submissions.filter((s: Submission) => s.assignmentId === assignment.id).map((sub: Submission) => (
                  <div key={sub.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-center gap-4 hover:shadow-md transition-all">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                      <UserIcon size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-gray-800">{sub.studentName}</h4>
                      <p className={cn(
                        "text-xs font-medium",
                        sub.status === 'graded' ? "text-brand-600" : "text-emerald-600"
                      )}>
                        {sub.status === 'graded' ? `Đã chấm: ${sub.grade} điểm` : `Đã nộp: ${sub.fileName}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <button 
                        onClick={() => setViewingSubmission(sub)}
                        className="p-2 text-gray-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-all"
                        title="Xem bài làm"
                      >
                        <Eye size={20} />
                      </button>
                      <input 
                        type="number" 
                        placeholder="Điểm"
                        className="w-20 p-2 bg-gray-50 border border-gray-200 rounded-lg text-center font-bold outline-none focus:ring-2 focus:ring-brand-500/20"
                        value={gradingValues[sub.id] ?? sub.grade ?? ''}
                        onChange={(e) => setGradingValues({ ...gradingValues, [sub.id]: parseInt(e.target.value) })}
                      />
                      <button 
                        onClick={() => handleGradeSubmission(sub.id)}
                        className={cn(
                          "px-4 py-2 rounded-lg text-xs font-bold transition-all",
                          sub.status === 'graded' ? "bg-gray-100 text-gray-400" : "btn-primary"
                        )}
                      >
                        {sub.status === 'graded' ? 'Cập nhật' : 'Trả bài'}
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4">Thống kê</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-2xl font-bold text-brand-600">12</div>
                <div className="text-xs text-gray-500">Đã giao</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-2xl font-bold text-emerald-600">
                  {submissions.filter((s: Submission) => s.assignmentId === assignment.id && s.status !== 'assigned').length}
                </div>
                <div className="text-xs text-gray-500">Đã nộp</div>
              </div>
            </div>
            <div className="mt-4 p-4 bg-brand-50 rounded-xl">
              <div className="text-2xl font-bold text-brand-600">
                {submissions.filter((s: Submission) => s.assignmentId === assignment.id && s.status === 'graded').length}
              </div>
              <div className="text-xs text-brand-600">Đã chấm điểm</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="flex items-center gap-4 border-b-2 border-brand-600 pb-6">
          <div className="w-12 h-12 bg-brand-50 rounded-full flex items-center justify-center text-brand-600">
            <FileText size={24} />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-800 mb-1">{assignment.title}</h1>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4 text-gray-500">
                <span>{teacherName}</span>
                <span>•</span>
                <span>{new Date(assignment.createdAt).toLocaleDateString('vi-VN')}</span>
              </div>
              <span className="font-bold text-gray-800">{assignment.points} điểm</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Clock size={16} className="text-brand-600" />
          Hạn chót: {new Date(assignment.dueDate).toLocaleDateString('vi-VN')}
        </div>

        <p className="text-gray-700 leading-relaxed">{assignment.description}</p>

        <div className="border-t border-gray-100 pt-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <MessageSquare size={18} className="text-gray-400" />
            Nhận xét lớp học
          </h3>
          <button className="text-sm text-brand-600 font-medium hover:underline">Thêm nhận xét lớp học...</button>
        </div>
      </div>

      <div className="space-y-6">
        {/* Submission Card */}
        <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-lg space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-gray-800">Bài tập của bạn</h3>
            <span className={cn(
              "text-xs font-bold px-2 py-1 rounded-md",
              mySubmission ? "text-emerald-600 bg-emerald-50" : "text-gray-500 bg-gray-50"
            )}>
              {mySubmission ? 'Đã nộp' : 'Đã giao'}
            </span>
          </div>

          {mySubmission ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 border border-gray-100 rounded-xl bg-gray-50">
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-red-500 shadow-sm">
                  <FileText size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-gray-800 truncate">{mySubmission.fileName}</p>
                  <p className="text-xs text-gray-400">PDF</p>
                </div>
              </div>
              <button className="w-full py-3 border-2 border-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-50 transition-all">
                Hủy nộp bài
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {file ? (
                <div className="flex items-center gap-3 p-3 border border-brand-200 rounded-xl bg-brand-50">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-red-500 shadow-sm">
                    <FileText size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-800 truncate">{file.name}</p>
                    <p className="text-xs text-gray-400">Tệp đã chọn</p>
                  </div>
                  <button onClick={() => setFile(null)} className="p-1 hover:bg-white rounded-full text-gray-400">
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <label className="w-full py-3 border-2 border-dashed border-gray-200 text-gray-500 font-medium rounded-xl hover:bg-gray-50 hover:border-brand-300 transition-all flex items-center justify-center gap-2 cursor-pointer">
                  <Upload size={20} />
                  Thêm hoặc tạo
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                  />
                </label>
              )}
              
              <button 
                onClick={handleTurnIn}
                disabled={isSubmitting || !file}
                className={cn(
                  "w-full py-3 font-bold rounded-xl transition-all shadow-lg",
                  file 
                    ? "bg-brand-600 text-white hover:bg-brand-700 shadow-brand-600/20" 
                    : "bg-gray-100 text-gray-400 shadow-none cursor-not-allowed"
                )}
              >
                {isSubmitting ? 'Đang nộp...' : 'Nộp bài'}
              </button>
            </div>
          )}
        </div>

        {/* Private Comments */}
        <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-gray-800 flex items-center gap-2">
            <UserIcon size={18} className="text-gray-400" />
            Nhận xét riêng tư
          </h3>
          <div className="flex gap-3">
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Thêm nhận xét cho giảng viên..."
              className="flex-1 text-sm bg-transparent border-b border-gray-200 focus:border-brand-600 outline-none py-1 transition-all"
            />
            <button className="text-brand-600 hover:bg-brand-50 p-1 rounded-full transition-colors">
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
