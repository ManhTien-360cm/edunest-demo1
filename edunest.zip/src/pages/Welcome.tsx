import { useAuth } from '../context/AuthContext';
import { motion } from 'motion/react';
import { BookOpen } from 'lucide-react';

export default function Welcome() {
  const { user, completeOnboarding } = useAuth();

  const getTitle = () => {
    if (user?.role === 'student') return 'Tài Khoản EDUNEST Học Sinh';
    if (user?.role === 'teacher') return 'Tài Khoản EDUNEST Giáo Viên';
    return 'EDUNEST Lớp học';
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-white">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center max-w-lg text-center"
      >
        <div className="w-24 h-24 bg-brand-600 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-brand-600/30 mb-8">
          <BookOpen size={48} />
        </div>

        <h1 className="text-4xl font-bold text-gray-900 mb-4 tracking-tight">
          {getTitle()}
        </h1>
        
        <p className="text-lg text-gray-500 mb-12 leading-relaxed">
          Giúp nhà giáo dục và học viên giao tiếp, tiết kiệm thời gian và sắp xếp nội dung một cách khoa học.
        </p>

        <button
          onClick={completeOnboarding}
          className="btn-primary px-12 py-4 text-lg rounded-2xl"
        >
          Bắt đầu
        </button>
      </motion.div>

      <footer className="absolute bottom-8 text-xs text-gray-400">
        Điều khoản dịch vụ • Chính sách bảo mật
      </footer>
    </div>
  );
}
