import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Role } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, EyeOff, GraduationCap, UserCircle } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Login() {
  const { login, register } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);
  const [role, setRole] = useState<Role>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      if (isRegistering) {
        if (password !== confirmPassword) {
          setError('Mật khẩu nhập lại không khớp');
          return;
        }
        await register(email, password, role);
      } else {
        await login(email, password);
      }
    } catch (err: any) {
      setError(err.message || 'Đã có lỗi xảy ra');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-brand-50 to-white">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 border border-gray-100"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {isRegistering ? 'Đăng ký' : 'Đăng nhập'}
          </h1>
          <p className="text-gray-500">
            {isRegistering ? 'Tạo tài khoản mới tại EDUNEST' : 'Chào mừng bạn đến với EDUNEST'}
          </p>
        </div>

        <div className="flex p-1 bg-gray-100 rounded-2xl mb-8">
          <button
            onClick={() => setRole('student')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all duration-200 font-medium",
              role === 'student' ? "bg-white text-brand-600 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <UserCircle size={20} />
            Học viên
          </button>
          <button
            onClick={() => setRole('teacher')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all duration-200 font-medium",
              role === 'teacher' ? "bg-white text-brand-600 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <GraduationCap size={20} />
            Giáo viên
          </button>
        </div>

        {error && (
          <div className="mb-6 p-3 bg-red-50 text-red-600 text-sm rounded-xl border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {isRegistering ? 'Tài khoản (Email)' : 'Tên đăng nhập hoặc Email'}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input-field"
              placeholder="example@edunest.vn"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Mật khẩu</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field pr-12"
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {isRegistering && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Nhập lại mật khẩu</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="input-field pr-12"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 cursor-pointer text-gray-600">
              <input type="checkbox" className="rounded border-gray-300 text-brand-600 focus:ring-brand-500" />
              Nhớ mật khẩu
            </label>
            {!isRegistering && (
              <a href="#" className="text-brand-600 font-medium hover:underline">Quên mật khẩu?</a>
            )}
          </div>

          <button type="submit" className="btn-primary w-full py-4 text-lg">
            {isRegistering ? 'Tạo tài khoản' : 'Đăng nhập'}
          </button>
        </form>

        <div className="mt-8">
          <div className="relative flex items-center justify-center mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <span className="relative px-4 bg-white text-sm text-gray-500">
              {isRegistering ? 'đã có tài khoản?' : 'hoặc đăng nhập với'}
            </span>
          </div>

          {isRegistering ? (
            <button 
              onClick={() => setIsRegistering(false)}
              className="w-full py-3 text-brand-600 font-medium hover:underline"
            >
              Quay lại đăng nhập
            </button>
          ) : (
            <button 
              onClick={() => setIsRegistering(true)}
              className="w-full py-3 px-4 border-2 border-gray-100 rounded-xl flex items-center justify-center gap-3 hover:bg-gray-50 transition-all duration-200 font-medium text-gray-700"
            >
              <div className="w-6 h-6 bg-brand-600 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">EN</div>
              Tạo tài khoản EDUNEST
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
