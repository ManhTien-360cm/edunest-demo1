export type Role = 'student' | 'teacher';

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  avatar?: string;
}

export interface Class {
  id: string;
  name: string;
  section?: string;
  subject?: string;
  room?: string;
  teacherId: string;
  teacherName: string;
  teacherEmail?: string;
  bannerColor: string;
  classCode: string;
}

export interface Assignment {
  id: string;
  classId: string;
  title: string;
  description: string;
  dueDate: string;
  createdAt: string;
  points: number;
  topicId?: string;
}

export interface Topic {
  id: string;
  classId: string;
  name: string;
  createdAt: string;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentId: string;
  studentName: string;
  studentEmail?: string;
  studentAvatar?: string;
  fileUrl?: string;
  fileName?: string;
  status: 'assigned' | 'turned-in' | 'graded';
  grade?: number;
  privateComment?: string;
  submittedAt?: string;
}

export interface Post {
  id: string;
  classId: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  createdAt: string;
}
