import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';
import { 
  onAuthStateChanged, 
  signOut, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, role: Role) => Promise<void>;
  logout: () => Promise<void>;
  isFirstTime: boolean;
  completeOnboarding: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isFirstTime, setIsFirstTime] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          setUser({
            id: firebaseUser.uid,
            email: firebaseUser.email || '',
            name: userData.name || firebaseUser.email?.split('@')[0] || 'User',
            role: userData.role as Role,
            avatar: userData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${firebaseUser.uid}`
          });
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const register = async (email: string, password: string, role: Role) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const firebaseUser = userCredential.user;
    
    const name = email.split('@')[0];
    const userData = {
      uid: firebaseUser.uid,
      email,
      name: name.charAt(0).toUpperCase() + name.slice(1),
      role,
      createdAt: new Date().toISOString(),
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${firebaseUser.uid}`
    };

    await setDoc(doc(db, 'users', firebaseUser.uid), userData);
    
    setUser({
      id: userData.uid,
      email: userData.email,
      name: userData.name,
      role: userData.role as Role,
      avatar: userData.avatar
    });
    setIsFirstTime(true); // New users go to onboarding
  };

  const logout = async () => {
    await signOut(auth);
    setIsFirstTime(true);
  };

  const completeOnboarding = () => {
    setIsFirstTime(false);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isFirstTime, completeOnboarding, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
