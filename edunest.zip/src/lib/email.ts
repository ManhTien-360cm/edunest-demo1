import emailjs from '@emailjs/browser';

// These should be set in environment variables
const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || 'service_id';
const TEMPLATE_ID_SUBMISSION = import.meta.env.VITE_EMAILJS_TEMPLATE_ID_SUBMISSION || 'template_submission';
const TEMPLATE_ID_GRADING = import.meta.env.VITE_EMAILJS_TEMPLATE_ID_GRADING || 'template_grading';
const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || 'public_key';

export const sendSubmissionNotification = async (
  teacherEmail: string,
  teacherName: string,
  studentName: string,
  assignmentTitle: string
) => {
  try {
    const templateParams = {
      to_email: teacherEmail,
      to_name: teacherName,
      from_name: studentName,
      assignment_title: assignmentTitle,
      message: `${studentName} đã nộp bài tập: ${assignmentTitle}`,
    };

    await emailjs.send(SERVICE_ID, TEMPLATE_ID_SUBMISSION, templateParams, PUBLIC_KEY);
    console.log('Email thông báo nộp bài đã được gửi');
  } catch (error) {
    console.error('Lỗi gửi email thông báo nộp bài:', error);
  }
};

export const sendGradingNotification = async (
  studentEmail: string,
  studentName: string,
  assignmentTitle: string,
  grade: number,
  teacherName: string
) => {
  try {
    const templateParams = {
      to_email: studentEmail,
      to_name: studentName,
      assignment_title: assignmentTitle,
      grade: grade,
      from_name: teacherName,
      message: `Giáo viên ${teacherName} đã chấm điểm bài tập ${assignmentTitle} của bạn. Điểm số: ${grade}`,
    };

    await emailjs.send(SERVICE_ID, TEMPLATE_ID_GRADING, templateParams, PUBLIC_KEY);
    console.log('Email thông báo điểm đã được gửi');
  } catch (error) {
    console.error('Lỗi gửi email thông báo điểm:', error);
  }
};
