import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Welcome from './pages/Welcome';
import Home from './pages/Home';
import ClassDetail from './pages/ClassDetail';
import { AnimatePresence } from 'motion/react';

function AppRoutes() {
  const { user, isFirstTime } = useAuth();

  if (!user) {
    return <Login />;
  }

  if (isFirstTime) {
    return <Welcome />;
  }

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/class/:classId" element={<ClassDetail />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <AnimatePresence mode="wait">
            <AppRoutes />
          </AnimatePresence>
        </div>
      </Router>
    </AuthProvider>
  );
}
